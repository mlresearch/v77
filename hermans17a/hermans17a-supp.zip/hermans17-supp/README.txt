View https://github.com/JoeriHermans/master-thesis/ for more information.

View https://github.com/cerndb/dist-keras/ about the optimization package that was used to test the optimizers.